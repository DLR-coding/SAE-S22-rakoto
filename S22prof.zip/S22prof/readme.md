compiler : 

gcc -o test2 test2.c graphe.c algos.c 

executer : 

./test2
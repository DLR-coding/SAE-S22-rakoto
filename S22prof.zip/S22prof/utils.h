#pragma once

#include <stdlib.h>

void generer_permutation(size_t *permutation, size_t n);
void init_aleatoire(double *val, size_t n, double max);
